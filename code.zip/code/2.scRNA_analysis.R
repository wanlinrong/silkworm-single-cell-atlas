#!/usr/bin/env Rscript

suppressPackageStartupMessages({
  library(Seurat)
  library(stringr)
  library(dplyr)
  library(patchwork)
  library(SingleR)
  library(celldex)
  library(scCustomize)
  library(clusterProfiler)
  library(ggplot2)
  library(ggrepel)
  library(ggpubr)
  library(cowplot)
  library(org.Hs.eg.db)
  library(org.Mm.eg.db)
  library(tidyverse)
  library(ggsci)
  library(argparse)
  library(paletteer)
  library(Polychrome)
  library(harmony)
  library(Matrix.utils)
  library(scuttle)
  library(Matrix)
  library(this.path)
  library(data.table)
  library(monocle3)
  library(tibble)
})

data.seurat <- Read10X(data.dir = "./matrix" ,gene.column = 1)
data.seurat <- CreateSeuratObject(counts = data.seurat,min.cells = 100,min.features = 0,project = "scRNA")
print(Sys.time())
print(paste0("对细胞barcode进行拆分，获取对应样本名称..."))
if (grepl("-S-",rownames(data.seurat@meta.data)[1])) {
  a = as.data.frame(do.call(rbind,strsplit(rownames(data.seurat@meta.data),"-S-")))
  data.seurat@meta.data$orig.ident = a[, ncol(a)]
  rm(a)
}

colnames(data.seurat@meta.data)[1] = "sample"
Idents(data.seurat) <- "sample"
n_sample <- length(unique(data.seurat@meta.data$sample))
sample <- unique(data.seurat@meta.data$sample)
data.seurat[["percent.mt"]] <- PercentageFeatureSet(data.seurat,pattern = "^KEF")

#Steps are optional
# Remove mitochondrial genes after QC filtering; they were used to compute the
# mitochondrial read ratio above and are excluded from downstream analyses
#mito_genes <- rownames(data.seurat)[grepl("^KEF", rownames(data.seurat))]
#data.seurat <- data.seurat[!rownames(data.seurat) %in% mito_genes, ]

# 计算每个样本的 nCount_RNA 的 99% 分位数，并存储到一个向量中
quantile_values_nCount_RNA <- sapply(unique(data.seurat@meta.data$sample), function(i) {
  quantile(data.seurat@meta.data[data.seurat@meta.data$sample == i, ]$nCount_RNA, probs = 0.99)
})
names(quantile_values_nCount_RNA) = sample
data.seurat@meta.data$quantile_values_nCount_RNA <- quantile_values_nCount_RNA[data.seurat@meta.data$sample]

data.seurat <- subset(data.seurat, subset = nFeature_RNA > 200 & nCount_RNA < quantile_values_nCount_RNA & percent.mt < 5)
data.seurat@meta.data$quantile_values_nCount_RNA <- NULL

# 去双胞
# 旧方法: DoubletDetection + per-sample 99th percentile,
# 曾用于早期版本的双胞评估
#   clf = doubletdetection.BoostClassifier()
#   clf.fit(counts)
#   score = clf.doublet_scores_
#   doublet = score > np.percentile(score, 99)

run_scDblFinder <- function(data.seurat, output_dir) {
  print(paste0("去除双胞"))
  library(scDblFinder)
  library(SingleCellExperiment)

  # ---- 转换为 SCE ----
  sce <- as.SingleCellExperiment(data.seurat)

  # ---- Per-sample 运行 scDblFinder ----
  set.seed(42)
  sce <- scDblFinder(sce, samples = "sample") # 指定样本列
  return(sce)
}
sce <- run_scDblFinder(data.seurat, output_dir)

# 写回 Seurat 并过滤
data.seurat$scDblFinder_class <- sce$scDblFinder.class
data.seurat <- subset(data.seurat, scDblFinder_class == "singlet")
rm(sce)

print(Sys.time())
print(paste0("HVG..."))
data.seurat <- NormalizeData(data.seurat, normalization.method = "LogNormalize", scale.factor = 10000)
data.seurat <- FindVariableFeatures(data.seurat, selection.method = "vst", nfeatures = 2000)

print(Sys.time())
print(paste0("PCA..."))
data.seurat <- ScaleData(data.seurat)
data.seurat <- RunPCA(data.seurat, features = VariableFeatures(object = data.seurat))

# 提取 PCA 的方差解释率
pca_variance <- data.seurat@reductions[["pca"]]@stdev
threshold <- 0.02 # 定义收敛的条件：当方差解释率的变化小于某个阈值时，认为已经收敛
differences <- diff(pca_variance) # 计算相邻点之间的差值
convergence_index <- which(abs(differences) < threshold)[1] # 找到差值小于阈值的点
convergence_x <- convergence_index + 1 # 提取收敛点的横坐标数值 加 1 是因为 diff() 减少了 1 个点

print(Sys.time())
print(paste0("运行harmony批次矫正..."))
Idents(data.seurat) = "sample"
data.seurat <- RunHarmony(data.seurat,reduction = "pca",group.by.vars = "sample",reduction.save = "harmony")
print(Sys.time())
print(paste0("细胞聚类分析..."))
data.seurat <- FindNeighbors(data.seurat,reduction = "harmony", dims = 1:convergence_x)
data.seurat <- FindClusters(data.seurat, resolution = 1.6)
data.seurat <- RunUMAP(data.seurat, reduction = "harmony", dims = 1:convergence_x, reduction.name = "umap")
data.seurat <- RunTSNE(data.seurat, reduction = "harmony", dims =1:convergence_x)


# SingleR
data.seurat_for_SingleR <- GetAssayData(data.seurat,layer = "counts")
aggregated <- SummarizedExperiment(assays=list(counts=data.seurat_for_SingleR),colData=data.seurat$cluster[match(colnames(data.seurat_for_SingleR),rownames(data.seurat@meta.data))])
aggregated <- logNormCounts(aggregated)
suppressWarnings(aggregated <- aggregateReference(aggregated,data.seurat$cluster[match(colnames(data.seurat_for_SingleR),rownames(data.seurat@meta.data))], power=0))
colnames(aggregated@colData) = "label.main"
rownames(aggregated@colData) = gsub("\\.1$","",rownames(aggregated@colData))
colnames(aggregated@assays@data@listData[["logcounts"]]) = rownames(aggregated@colData)
data.seurat_for_SingleR = as(as.matrix(aggregated@assays@data@listData[["logcounts"]]),"dgCMatrix")
if (geneid_mapping_file != "None" ) {
convert_gene_id = read.table(geneid_mapping_file,sep = "\t",header = T)
row_gene_name = data.frame(gene_id=rownames(data.seurat))
indices = match(row_gene_name$gene_id,convert_gene_id$geneID)
new_gene_name <- data.frame(
    gene_id = row_gene_name$gene_id,
    gene_name = ifelse(is.na(indices), 
                        row_gene_name$gene_id,  # 未匹配的保留原基因ID
                        convert_gene_id$geneName[indices])  # 匹配的转换为基因名称
)
# 处理重复基因名称：对相同基因名称的表达量求和  
expr_matrix <- as.matrix(data.seurat_for_SingleR)  
expr_aggregated <- aggregate(                      
    x = expr_matrix,
    by = list(gene_name = new_gene_name$gene_name),
    FUN = sum
)

rownames(expr_aggregated) <- expr_aggregated$gene_name # 设置行名为唯一标识（基因名称或原基因ID）
expr_aggregated$gene_name <- NULL
colnames(expr_aggregated) <- colnames(data.seurat_for_SingleR)
expr_aggregated <- as(as.matrix(expr_aggregated), "dgCMatrix")
data.seurat_for_SingleR <- expr_aggregated
}

ref = readRDS("ref_species.rds")
rownames(data.seurat_for_SingleR) = toupper(rownames(data.seurat_for_SingleR))
rownames(ref) = toupper(rownames(ref))
rownames(ref@assays@data@listData$logcounts) = toupper(rownames(ref@assays@data@listData$logcounts))
data.seurat.hesc <- SingleR(test = data.seurat_for_SingleR, ref = ref, labels = ref$label.main)
data.seurat@meta.data$cells_annotation <- data.seurat@meta.data$cluster
df_annotation = data.frame(cluster=rownames(data.seurat.hesc),labels = data.seurat.hesc$labels)
data.seurat@meta.data$cells_annotation = df_annotation$labels[match(data.seurat@meta.data$cells_annotation,df_annotation$cluster)]


# manual annotation
# ---
#

saveRDS(data.seurat, "seurat.rds")
features <- rownames(data.seurat)
barcodes <- colnames(data.seurat)
sc_matrix <- GetAssayData(data.seurat,layer="counts")
writeMM(sc_matrix, file= "matrix.mtx")
write.table(barcodes, "barcodes.tsv", row.names = FALSE, col.names = FALSE, quote = FALSE, sep = "\t")
write.table(features, "features.tsv", row.names = FALSE, col.names = FALSE, quote = FALSE, sep = "\t")
print("压缩文件...")
system(paste0("gzip -f ", 
              "barcodes.tsv ",
              "features.tsv ",
              "matrix.mtx "))