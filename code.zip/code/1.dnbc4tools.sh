#!/bin/bash

dnbc4tools rna mkref --fasta GCF_030269925.1_ASM3026992v2_genomic.fna --ingtf GCF_030269925.1_ASM3026992v2_genomic.gtf --species silkworm --threads 16

dnbc4tools rna run --cDNAfastq1 sample*.fq.gz --cDNAfastq2 sample*.fq.gz --oligofastq1  sample*.fq.gz --oligofastq2  sample*.fq.gz --genomeDir genomeDir --name sample* --threads 16

