#!/usr/bin/env Rscript
# .libPaths("/path/to/R/library")  # set your own R library path if required

suppressMessages({
    library(Seurat)
    library(stringr)
    library(dplyr)
    library(Matrix)
    library(Matrix.utils)
    library(data.table)
    library(tidyverse)
    library(igraph)
    library(psych)
})
set.seed(123)

# ---- input files (edit these paths before running) ----
matrix_dir <- "path/to/FilteredMatrix"
metadata_file <- "path/to/cell_metadata.xls"
annotation_file <- "path/to/annotation.xls"

# ---- expression matrix ----
exp_mat <- Read10X(matrix_dir, gene.column = 1)

metadata <- fread(metadata_file, header = TRUE)
annotation <- fread(annotation_file, header = TRUE)
annotation$level1 <- str_remove(annotation$level1,"s$")
# annotation$level1 <- str_replace_all(annotation$level1, "[[:space:]]", "_")
annotation$cluster_annotation <- str_replace_all(annotation$cluster_annotation, "[[:space:]]", "_")
metadata$cluster_annotation <- str_replace_all(metadata$cluster_annotation, "[[:space:]]", "_")
metadata$broad_annotation <- annotation$level1[match(metadata$cluster_annotation, annotation$cluster_annotation)]

celltype_count <- as.numeric(table(metadata$cluster_annotation))
celltype_sum <- aggregate.Matrix(
  t(exp_mat),
  groupings = metadata$cluster_annotation,
  fun = "sum"
)
celltype_exp <- t(celltype_sum / celltype_count) %>% as.data.frame() %>% rownames_to_column("gene")
fwrite(celltype_exp, "celltype_MeanExpression.tsv", sep = "\t")
celltype_exp <- fread("celltype_MeanExpression.tsv", header = TRUE)

broadtype_count <- as.numeric(table(metadata$broad_annotation))
broadtype_sum <- aggregate.Matrix(
  t(exp_mat),
  groupings = metadata$broad_annotation,
  fun = "sum"
)
broadtype_exp <- t(broadtype_sum / broadtype_count) %>% as.data.frame() %>% rownames_to_column("gene")
fwrite(broadtype_exp, "broadtype_MeanExpression.tsv", sep = "\t")


# ---- correlation ----
data <- read.table("celltype_MeanExpression.tsv",header = T,row.names = 1, check.names=FALSE)
type <- metadata %>%
  select(cluster_annotation, broad_annotation) %>%
  distinct() %>%
  rename(node = cluster_annotation, type = broad_annotation)
fwrite(type, "broad_type.tsv", sep = "\t")
cor <- corr.test(data, use = "pairwise",method="spearman",adjust="holm", alpha=.05, ci=FALSE) # ci=FALSE,不进行置信区间计算，数据量较大时，可以加快计算速度。

cor.r <- data.frame(cor$r) # 提取R值
cor.p <- data.frame(cor$p) # 提取p值
colnames(cor.r) = rownames(cor.r)
colnames(cor.p) = rownames(cor.p) # 变量名称中存在特殊字符，为了防止矩阵行名与列名不一致，必须运行此代码。

write.table(cor.r,"cluster.cor.r.xls",quote = FALSE) # 保存结果到本地
write.table(cor.p,"cluster.cor.p.xls",quote = FALSE)

#### 将数据转换为long format进行过滤，后面绘制网络图需要节点和链接数据，在这一步可以完成格式整理
cor.r$node1 = rownames(cor.r) 
cor.p$node1 = rownames(cor.p)

r = cor.r %>% 
  gather(key = "node2", value = "r", -node1) %>%
  data.frame()

p = cor.p %>% 
  gather(key = "node2", value = "p", -node1) %>%
  data.frame()
head(r)
head(p)

#### 将r和p值合并为一个数据表
cor.data <- merge(r,p,by=c("node1","node2"))
cor.data

save.image(file = "./igraph.cluster.RData")

#### 保留p<=0.01且abs(r)>=0.9的变量间相关关系，并添加网络属性
cor.data <- cor.data %>%
  filter(abs(r) >= 0.9, p <= 0.01, node1 != node2) %>%
  mutate(
    linetype = ifelse(r > 0,"positive","negative"), # 设置链接线属性，可用于设置线型和颜色。
    linesize = abs(r) # 设置链接线宽度。
  ) # 此输出仍有重复链接，后面需进一步去除。

#### 去除
sorted_df <- t(apply(cor.data[, 1:2], 1, sort))
# 将排序后的结果和原数据框的其他列合并
df_sorted <- cbind(sorted_df, cor.data[, -(1:2)])
# 删除重复行
cor.data <- unique(df_sorted)
colnames(cor.data) <- c("node1","node2","r","p","linetype","linesize")
head(cor.data)

### 3.1 网络图节点属性整理
#### 计算每个节点具有的链接数
c(as.character(cor.data$node1),as.character(cor.data$node2)) %>%
  as_tibble() %>%
  group_by(value) %>%
  summarize(n=n()) -> vertices
colnames(vertices) <- c("node", "n")

#### 添加变量分类属性
vertices %>%
  select(-n) %>% # 因为此处的n不准确（去除后准确），所以先删除。
  left_join(type,by="node") -> vertices 

#### 网络图中节点会按照节点属性文件的顺序依次绘制，为了使同类型变量位置靠近，按照节点属性对节点进行排序。
vertices$type = factor(vertices$type,levels = unique(vertices$type))
vertices = arrange(vertices,type)
# colnames(vertices) <- c("node", "type")
write.table(vertices,"vertices.tsv",sep="\t",quote = FALSE,col.names = TRUE,row.names = FALSE)
head(vertices)
### 3.2 构建graph结构数据
write.table(cor.data,"dataframe.tsv",sep="\t",quote = FALSE,col.names = TRUE,row.names = FALSE)
g <- graph_from_data_frame(cor.data, vertices = vertices, directed = FALSE )
g
vcount(g) # 节点数目：33
ecount(g) # 链接数:81
#get.vertex.attribute(g) # 查看graph中包含的节点属性
#get.edge.attribute(g) # 查看graph中包含的链接属性

### 3.4 计算节点链接数
V(g)$degree <- degree(g)
#vertex.attributes(g)
#edge.attributes(g) 
g

### 4.1 设置绘图颜色
## 必须以此顺序来设置
unique(V(g)$type)
# color <- c("B"="#62B197", "Endothelial_cells"="#DF811C", "Epithelial_cells"="#57ABDC", 
#            "Lymphoid_cells"="#8F4C9A", "Mesenchymal_cells"="#6C9A8F", "Myeloid_cells"="#E58560",
#            "Neuronal_cells"="#3778AD","Primordial_germ_cell"="#E0AB17","T"="#2DAFB6")
source("/psd/dsbc/lib/R/dsbcColorsDiscrete.R")
# color <- dsbcColorsDiscrete(name="default",n=length(unique(type$type)))
# names(color) <- unique(type$type)
# color <- color[unique(V(g)$type)]

# color <- dsbcColorsDiscrete(name="default",n=length(unique(V(g)$type)))
# names(color) <- unique(V(g)$type) # 将颜色以节点分类属性命名

colors <- fread("celltype_colors.tsv", header = F)
broad_type <- sort(unique(type$type))
color <- colors$V1[1:length(broad_type)]
names(color) <- broad_type
V(g)$point.col <- color[match(V(g)$type,names(color))] # 设置节点颜色.

data.frame(type = names(color), color = color) %>%
  fwrite("broadtype_colors.tsv", sep = "\t", quote = FALSE, row.names = FALSE, col.names = TRUE)

#### 边颜色按照相关性正负设置
#E(g)$color <- ifelse(E(g)$linetype == "positive",rgb(255,215,0,maxColorValue = 255),"gray50")
#E(g)$color <- ifelse(E(g)$linetype == "positive","red",rgb(0,147,0,maxColorValue = 255))
E(g)$color <- "steelblue"


### 设置igraph layout样式
layout_functions <- c(
  # "component_wise",
  # "layout_as_bipartite",
  "layout_as_star",
  "layout_as_tree",
  "layout_in_circle",
  "layout_nicely",
  "layout_on_grid",
  "layout_on_sphere",
  "layout_randomly",
  "layout_with_dh",
  "layout_with_fr",
  "layout_with_gem",
  "layout_with_graphopt",
  "layout_with_kk",
  "layout_with_lgl",
  "layout_with_mds",
  "layout_with_sugiyama"
  # "merge_coords",
  # "norm_coords",
  # "normalize"
)

# output_dir <- "graph_layouts"
output_dir <- "graph_layouts_color"
if (!dir.exists(output_dir)) {
  dir.create(output_dir)
}

for (layout_name in layout_functions) {
  # 获取布局函数
  layout_func <- get(layout_name)
  # print(layout_func)
  layout <- layout_func(g)
  cat("\nLayout:", layout_name)
  pdf(file.path(output_dir, paste0(layout_name, ".pdf")), family = "Times", width = 8,height = 8)
  #par(mar=c(5,2,1,2))  #边距

  plot.igraph(g, layout=layout,
              vertex.color=V(g)$point.col,
              vertex.frame.color ="white",
              vertex.border=V(g)$point.col,
              ##节点大小设置参数##
              shape = 1,# 设置点形状
              vertex.size=3, 
              rescale =TRUE, # 默认设置
              vertex.label= "",
              mark.col=color,
              mark.border=color,
  #           edge.arrow.size=5,
              edge.width=0.1,
              edge.curved = FALSE #直线
  )

  legend("bottomright",title = "Type",
        legend = c(unique(V(g)$type)),
        fill = color[c(unique(V(g)$type))],
  )
  dev.off()
}

