#!/usr/bin/env Rscript
# =============================================================================
# GO over-representation analysis for several gene groups + enrichment map
# -----------------------------------------------------------------------------
# Input files (all tab-separated, supplied through `opt`):
#   opt$go2gene          : term -> gene mapping              (no header)
#   opt$go2term          : term -> term description          (no header)
#   opt$selectedGeneList : selected genes with group label   (header: geneid, group)
#   opt$colorConf        : group label -> color              (no header)
#
# Main steps:
#   1. read the annotation mappings, the gene list and the color settings
#   2. GO enrichment for each group (compareCluster + enricher)
#   3. compute term-term similarity and draw the enrichment map (emapplot)
#   4. export the figure as PDF
# =============================================================================

library(ggplot2)
library(enrichplot)
library(clusterProfiler)

## ---- 0. default plotting options (can be overridden via `opt`) --------------
if (is.null(opt$proportion)) opt$proportion <- TRUE   # draw pies instead of dots
if (is.null(opt$legends))    opt$legends    <- 20     # max legend items
if (is.null(opt$width))      opt$width      <- 10     # output width (inch)
if (is.null(opt$height))     opt$height     <- 8      # output height (inch)

## ---- 1. read inputs --------------------------------------------------------
go2gene  <- read.table(opt$go2gene, sep = "\t", header = FALSE, stringsAsFactors = FALSE)
go2term  <- read.table(opt$go2term, sep = "\t", header = FALSE, stringsAsFactors = FALSE)
genelist <- read.table(opt$selectedGeneList, sep = "\t", header = TRUE, stringsAsFactors = FALSE)

# color settings: the second column holds the colors
colorConf <- read.table(opt$colorConf, sep = "\t", header = FALSE, comment.char = "", stringsAsFactors = FALSE)
color <- colorConf[, 2]

## ---- 2. GO enrichment analysis for each group -------------------------------
enrichResult <- compareCluster(geneid ~ group,
                               data      = genelist,
                               fun       = "enricher",
                               TERM2GENE = go2gene,
                               TERM2NAME = go2term)

# number of terms to show: all terms by default
showCategory <- opt$showCategory
if (is.null(showCategory) || is.na(showCategory) || showCategory <= 0) {
  showCategory <- nrow(enrichResult)
}

## ---- 3. term-term similarity + enrichment map -------------------------------
termsimResult <- pairwise_termsim(enrichResult, showCategory = showCategory)

p <- emapplot(termsimResult,
              showCategory = showCategory,
              pie.params  = list(pie      = opt$proportion,
                                 legend_n = opt$legends)) +
  scale_fill_manual(values = color)

## ---- 4. export --------------------------------------------------------------
ggsave(p, file = paste0(opt$outpre, ".pdf"),
       width = opt$width, height = opt$height)