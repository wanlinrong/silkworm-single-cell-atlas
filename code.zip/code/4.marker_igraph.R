#!/usr/bin/Rscript

suppressPackageStartupMessages(library(optparse))
suppressPackageStartupMessages(library(tidyverse))
suppressPackageStartupMessages(library(igraph))
suppressPackageStartupMessages(library(psych))
suppressPackageStartupMessages(library(dplyr))
source("dsbcColorsDiscrete.R")
option_list <- list(
  make_option(c("-i", "--input"), type="character", default=NULL, help="edge file, header: node1 node2 linesize", metavar="character"),
  make_option(c("-n", "--edgenumber"), type="numeric", default=1000, help="number of highest linesize, default 1000", metavar="numeric"),
  make_option(c("-r", "--edgeratio"), type="numeric", default=0, help="ratio of highest linesize, default 0, plot the larger one of --edgenumber and --edgeratio", metavar="numeric"),
  make_option(c("-v", "--vertices"), type="character", default=NULL, help="vertices file, header: node type", metavar="character"),
  make_option(c("-f", "--format"), type="numeric", default=0, help="select vertices file format, default: 0\n\t\t0: node type; 1: node type (degree); 2: node type size;\n\t\t3: node type (degree) weight; 4: node type size weight;", metavar="numeric"),
  make_option(c("-t", "--labeltypes"), type="character", default=NULL, help="types in --vertices to be labeled", metavar="character"),
  make_option(c("-m", "--mapping"), type="character", default=NULL, help="name mapping file, header: node name", metavar="character"),
  make_option(c("-x", "--colorset"), type="character", default="default", help="colorset from /psd/dsbc/lib/R/dsbcColorsDiscrete.R, default: default", metavar="character"),
  make_option(c("-c", "--colorfile"), type="character", default=NULL, help="color file, header: type color, this overwrite --colorset", metavar="character"),
  make_option(c("-o", "--output"), type="character", default="graph_layouts", help="output folder of the PDF file", metavar="character"),
  make_option(c("-s", "--vertexsize"), type="numeric", default=20, help="vertex size, default 20", metavar="numeric"),
  make_option(c("-w", "--edgewidth"), type="numeric", default=0.001, help="edge width, default 0.001", metavar="numeric"),
  make_option(c("-a", "--arrowsize"), type="numeric", default=0.005, help="edge size, default 0.005", metavar="numeric"),
  make_option(c("-l", "--labelsize"), type="numeric", default=0.4, help="label size, default 0.4", metavar="numeric"),
  make_option(c("-e", "--seed"), type="numeric", default=1, help="set a custom random seed. default: 1"),
  make_option(c("-L", "--nrows"), type="numeric", default=4, help="set number of columns of legend, default 4", metavar="numeric"),
  make_option(c("-W", "--width"), type="numeric", default=7, help="pdf width,default 7", metavar="numeric"),
  make_option(c("-H", "--height"), type="numeric", default=7, help="pdf height,default 7", metavar="numeric"),
  make_option("--log2", action="store_true", default=FALSE, help="enable log2 transformation [FALSE]")
)
# 解析命令行参数
args <- parse_args(OptionParser(option_list=option_list))
set.seed(args$seed)

## read edge file
data <- read.table(args$input,header = T)[,c(1,2,3)]
colnames(data) <- c("node1","node2","linesize")
if (nrow(data) * args$edgeratio > args$edgenumber){
    data <- data[data[,3] > quantile(data[,3], probs = 1 - args$edgeratio),]
}else{
    data <- head(data[order(data$linesize, decreasing = TRUE), ], args$edgenumber)
}

## read vertices file
vert <- read.table(args$vertices, header = TRUE, sep = "\t")

create_dataframe <- function(vert, type_option = 0) {
  if (type_option == 0 || type_option == 1) {
    # 默认：只有 node 和 type
    type <- data.frame(
      node = vert[, 1],
      type = vert[, 2],
      stringsAsFactors = FALSE
    )
    colnames(type) <- c("node", "type")
  } else if (type_option == 2) {
    # node + type + size（vertex）
    type <- data.frame(
      node = vert[, 1],
      type = vert[, 2],
      vertex = vert[, 3],
      stringsAsFactors = FALSE
    )
    colnames(type) <- c("node", "type", "vertex")
  } else if (type_option == 3) {
    # node + type + weight
    type <- data.frame(
      node = vert[, 1],
      type = vert[, 2],
      weight = vert[, 3],
      stringsAsFactors = FALSE
    )
    colnames(type) <- c("node", "type", "weight")
  } else if (type_option == 4) {
    # node + type + size + weight
    type <- data.frame(
      node = vert[, 1],
      type = vert[, 2],
      vertex = vert[, 3],
      weight = vert[, 4],
      stringsAsFactors = FALSE
    )
    colnames(type) <- c("node", "type", "vertex", "weight")
  } else {
    stop("Invalid type_option. Must be 0, 1, 2, 3 or 4.")
  }
  return(type)
}

type_option <- args$format
type <- create_dataframe(vert, type_option) 

type <- type[type$node %in% unique(c(data$node1, data$node2)),]
# str(type)

## read name mapping file
if (! is.null(args$mapping)){
    nodename <- read.table(args$mapping,header = T)[,c(1,2)]
    colnames(nodename) <- c("node","name")
}else{
    nodename <- data.frame(node = unique(type$node), name = unique(type$node))
}
nodename <- nodename[nodename$node %in% unique(c(data$node1, data$node2)),]

## get color
color <- dsbcColorsDiscrete(name=args$colorset,n=length(unique(type$type)))
names(color) <- unique(type$type)

if (!is.null(args$colorfile)){
    tmp <- read.table(args$colorfile, header = TRUE, sep = "\t",comment.char = "")[,c(1,2)]
    print(tmp)
    color <- tmp[,2]
    names(color) <- tmp[,1]
}
cat("color set:\n")
print(color)






### 构建graph结构数据
g <- graph_from_data_frame(data, vertices = type, directed = FALSE )
cat(sprintf("\nNetwork Stats\nNodes: %d\nEdges: %d\n", 
            vcount(g), ecount(g)))
#get.vertex.attribute(g) # 查看graph中包含的节点属性
#get.edge.attribute(g) # 查看graph中包含的链接属性

vertices  <- igraph::as_data_frame(g, what = "both")$vertices # 提取节点属性

#label
custom_labels <- vertices$name
if (!is.null(args$labeltypes)) {
  needtypes <- unlist(strsplit(args$labeltypes, split = ","))
} else {
  needtypes <- unique(type$type)
  needtypes <- NULL
}

cat("\nneedtypes:\n")
print(needtypes)
indices <- match(type[type$type %in% needtypes, "node"], vertices$name)
indices <- na.omit(indices)
if (length(indices) != 0) {
  custom_labels[-indices] <- ""
} else {
  custom_labels <- ""
}

#替换
custom_labels <- ifelse(custom_labels %in% nodename$node,
                        nodename$name[match(custom_labels, nodename$node)],
                        custom_labels)

#### 边颜色按照相关性正负设置
E(g)$color <- "steelblue"

### 绘制径向布局网络图
arrowsize <- args$arrowsize
edgewidth <- args$edgewidth
vertexsize <- args$vertexsize
labelsize <- args$labelsize

### 计算节点链接数
if (args$log) {
  V(g)$degree <- log2(degree(g) + 1)
} else {
  V(g)$degree <- degree(g)
}
maxdgree <- max(V(g)$degree)
V(g)$degree <- V(g)$degree / maxdgree

if (type_option == 2 || type_option == 4) {
  cat("\nuse custom vertex size\n")
  V(g)$vertex <- type$vertex
  if (args$log) {
    V(g)$vertex <- log2(V(g)$vertex + 1)
  } else {
    V(g)$vertex <- V(g)$vertex
  }
  maxvertex <- max(V(g)$vertex)
  V(g)$vertex <- V(g)$vertex / maxvertex
  V(g)$size <- V(g)$vertex * vertexsize
} else if (type_option == 0) {
  cat("\nuse fixed size as vertex size\n")
  V(g)$size <- vertexsize
} else {
  # 只有node和type列时：使用degree
  cat("\nuse degree as vertex size\n")
  V(g)$size <- V(g)$degree * vertexsize
}

print(V(g)$size)
summary(V(g)$size)

### 设置绘图颜色
##color
if (type_option == 0 || type_option == 1 || type_option == 2) {
  V(g)$point.col <- color[match(V(g)$type, names(color))] # 设置节点颜色。
} else {
  # 生成颜色梯度函数
  library(colorspace)
  library(monochromeR)
  ############################# function #############################
  generate_palette <- function(colour, modification, n_colours,
                             blend_colour = NULL,
                             view_palette = FALSE, view_labels = TRUE, ...) {
    # Allows for US spelling input
    check_dots <- list(...)

    if(missing(colour) & "color" %in% names(check_dots)) {
      colour <- check_dots$color
    }

    if(missing(n_colours) & "n_colors" %in% names(check_dots)) {
      n_colours <- check_dots$n_colors
    }

    if("blend_color" %in% names(check_dots)) {
    blend_colour <- check_dots$blend_color
    }

    col_rgb <- check_colour_return_rgb(colour, "colour")
    if(!is.null(blend_colour)){
      bg_col <- c(check_colour_return_rgb(blend_colour, "blend_colour"))
      # message("
      #   Because you supplied a blend_colour, the modification variable is set to \"blend\".
      #   To use other modification options (\"go_darker\", \"go_lighter\" or \"go_both_ways\"),
      #   leave blend_colour as NULL."
      # )
      modification <- "blend"
    } else if(modification == "go_darker") {
      bg_col <- "black"
    } else if(modification == "go_lighter") {
      bg_col <- "white"
    }

    # if it's go both ways, need to do black and white separately for n_colours/2
    alpha_values <- seq(from = 1, to = 0.2, length.out = ifelse(modification == "go_both_ways",
                                                                floor(n_colours/2) + 1,
                                                                n_colours))

    generated_palette <- c()

    if(modification == "go_both_ways"){
      for (alpha_value in sort(alpha_values)) {
        generated_palette <- c(generated_palette, rgba_to_hex(c(col_rgb, alpha_value), "white"))
      }
      for (alpha_value in alpha_values) {
        generated_palette <- c(generated_palette, rgba_to_hex(c(col_rgb, alpha_value), "black"))
      }
      generated_palette <- unique(generated_palette)[1:n_colours]

    } else {
      for (alpha_value in alpha_values) {
        generated_palette <- c(generated_palette, rgba_to_hex(c(col_rgb, alpha_value), bg_col))
      }
    }

    if(view_palette == TRUE) {
      print(view_palette(generated_palette, view_labels = view_labels))
    }

    return(generated_palette)

    if(!modification %in% c("go_darker", "go_lighter", "go_both_ways", "blend")) {
      stop("modification must be one of the following: \"go_darker\", \"go_lighter\", \"go_both_ways\", or \"blend\"")
    }
  }

  generate_gradient <- function(base_color, n) {
    colors <- unlist(strsplit(base_color, ","))
    if (length(colors) == 2) {
      color_light = as.character(colors[1])
      color_dark = as.character(colors[2])
      palette <- generate_palette(
        colour=color_light,             # 起始颜色
        modification = "blend",         # 双色渐变
        blend_colour = color_dark,      # 终止颜色
        n_colours = n,                  # 颜色数目   
        view_palette = T,               # 完成后展示调色板  
        view_labels=T                   # 展示颜色的十六进制  
      )
    } else {
      color = base_color
      palette <- generate_palette(
        colour=base_color,              # 颜色值
        modification = "go_lighter",    # 单色渐变
        n_colours = n,                  # 颜色数目   
        view_palette = T,               # 完成后展示调色板  
        view_labels=T                   # 展示颜色的十六进制  
      )
      palette <- rev(palette)
    }
    return(palette)
  }
  # 计算分位数
  n_levels <- 5  # 可根据数据分布调整
  bins <- quantile(V(g)$weight, c(seq(from = 0, to = 1, length = n_levels)), na.rm = TRUE)

  # 格式化输出
  cat("\nWeight bins:\n")
  cat(sprintf("%8s", names(bins)), "\n")  # 对齐分位数标签
  cat(sprintf("%8.2f", bins), "\n")       # 保留2位小数
  V(g)$weight_level <- unlist(lapply(V(g)$weight, function(x) min(which(bins >= x))))
  print(V(g)$weight_level)

  # 为所有type创建颜色梯度表
  color_gradients <- lapply(color, function(col) {
    generate_gradient(col, n_levels)
  })
  color_gradients

  V(g)$point.col <- sapply(V(g)$name, function(name) {
    type <- V(g)$type[V(g)$name == name]
    level <- V(g)$weight_level[V(g)$name == name]
    color_gradients[[type]][level]
  })
}
cbind(V(g)$name, V(g)$point.col)

### 设置igraph layout样式
layout_functions <- c(
  # "component_wise",
  # "layout_as_bipartite",
  "layout_as_star",
  "layout_as_tree",
  "layout_in_circle",
  "layout_nicely",
  "layout_on_grid",
  "layout_on_sphere",
  "layout_randomly",
  "layout_with_dh",
  "layout_with_fr",
  "layout_with_gem",
  "layout_with_graphopt",
  "layout_with_kk",
  "layout_with_lgl",
  "layout_with_mds",
  "layout_with_sugiyama"
  # "merge_coords",
  # "norm_coords",
  # "normalize"
)

# layout_functions <- c(
#   "layout_nicely"
# )

output_dir <- args$output
if (!dir.exists(output_dir)) {
  dir.create(output_dir)
}

for (layout_name in layout_functions) {
  # 获取布局函数
  layout_func <- get(layout_name)
  # print(layout_func)
  layout <- layout_func(g)
  cat("\nLayout:", layout_name, "\n") 
  pdf(file.path(output_dir, paste0(layout_name, ".pdf")), width = args$width, height = args$height)
  if (type_option == 3 || type_option == 4) {
    layout(matrix(c(1, 2), nrow = 2), heights = c(0.8, 0.2))
    par(mar = c(0, 0, 0, 0))
  } else {
    par(mar = c(1, 1, 1, 1))
  }
  plot.igraph(g, layout=layout,
              vertex.color=V(g)$point.col,
              vertex.frame.color ="gray20",
              vertex.border=V(g)$point.col,
              vertex.label=custom_labels,
              vertex.label.dist=0,
              vertex.label.cex=labelsize,
              vertex.frame.width=0.01,
              shape = 1,              # 设置点形状
              vertex.size=V(g)$size,  # 节点大小
              # vertex.size=10,  # 节点大小
              rescale =TRUE,          # 默认设置
              mark.col=color,
              mark.border=color,
              edge.arrow.size=V(g)$size*arrowsize,
              edge.width=data$linesize*edgewidth,
              edge.curved = FALSE     #直线
  )

  if (type_option == 3 || type_option == 4) {
    # par(mar = c(0, 0, 0, 0))
    plot(1, type = "n", xlim = c(0, 1), ylim = c(0, 1), axes = FALSE, xlab = "", ylab = "")

    # --- 参数配置 ---
    ncol <- args$nrows              # 列数（可修改为2、3、4...）
    start_y <- 1                    # 起始y位置（顶部）
    end_y <- 0.2                    # 终止y位置（底部）
    x_start <- 0.25                 # x起始位置
    x_end <- 0.75                   # x结束位置
    max_block_height <- 0.1         # 颜色块最大高度（避免过大）

    # --- 动态计算行参数 ---
    n_items <- length(color_gradients)            # 图例总数
    nrow <- ceiling(n_items / ncol)               # 总行数
    total_height <- start_y - end_y               # 可用总高度
    row_spacing <- total_height / (nrow * 2.5)    # 行间距（自动计算）
    # 计算每列的中心x坐标
    x_positions <- seq(x_start, x_end, length.out = ncol)

    # --- 绘制图例 ---
    for (i in seq_along(color_gradients)) {
      cell_type <- names(color_gradients)[i]
      colors <- color_gradients[[i]]
      
      # 计算当前行和列
      row <- ceiling(i / ncol)
      col <- (i - 1) %% ncol + 1
      print(paste("row:", row, "col:", col))
      # 计算中心位置
      x_center <- x_positions[col]
      y_center <- start_y - (row - 1) * row_spacing * 2.5  # y位置（从顶部递减）
      # 绘制颜色块（仅当颜色数量 > 1）
      if (length(colors) > 1) {
        block_width <- 0.8 * (x_end - x_start) / (ncol * length(colors))
        x_left <- x_center - block_width * length(colors) / 2
        
        for (j in 1:length(colors)) {
          rect(
            xleft = x_left + (j-1) * block_width,
            ybottom = y_center - row_spacing,
            xright = x_left + j * block_width,
            ytop = y_center,
            col = colors[j],
            border = NA
          )
        }
        # 添加标签（居中）
        text(
          x = x_center,
          y = y_center - row_spacing / 2,  # 标签在颜色块下方
          labels = cell_type,
          cex = 0.6,
          pos = 1  # 文字在坐标下方
        )
      }
    }
  } else {
    present_types <- unique(V(g)$type)
    used_colors <- color[names(color) %in% present_types]

    legend("bottomright",title = "Type",
          legend = names(used_colors),
          fill = used_colors,
    )
  }
  present_types <- unique(V(g)$type)
  used_colors <- color[names(color) %in% present_types]
  dev.off()
}
cat("\n\nR-igraph plot completed!\n")
