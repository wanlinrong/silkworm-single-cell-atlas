#!/usr/bin/env Rscript
# https://github.com/EmilHvitfeldt/r-color-palettes
# https://github.com/clauswilke/colorblindr
# https://pmassicotte.github.io/paletteer_gallery/
# https://personal.sron.nl/~pault/
# https://cran.r-project.org/web/packages/wacolors/readme/README.html
# dengcao@dnastories.com
# 20250313 meiyichao
dsbcColorsDiscrete <- function(name="default",n=0,plot=FALSE)
{
  #################################################################################
  ################################### configure ###################################
  #################################################################################
  ggsci <- data.frame(npg=10,lancet=9,d3=10,startrek=7,tron=7,futurama=12,rickandmorty=10,simpsons=10) # have not checked for color blindness
  RColorBrewer <- data.frame(Dark2=8,Paired=12,Set2=8) # all for color blindness
  grafify<-data.frame(okabe_ito=9,bright=7,contrast=5,dark=6,kelly=20,light=9,
                      muted=10,pale=6,r4=6,safe=11,vibrant=7,fishy=9,all_grafify=55)#all for color blindness
  custom <- data.frame(default=21,dis_111=111,dis_333=333,oat=3,macaca=9,cm104pair=16,cm104dark=8,cm104light=8,TBP=11)
  
  maxcolors <- cbind(custom,grafify,RColorBrewer,ggsci)
  namelist <- colnames(maxcolors)
  
  #################################################################################
  ############################## check parameters    ##############################
  #################################################################################
  n<- as.numeric(n)
  if (!(name %in% namelist)) {
    stop(paste(name, "is not a valid palette name for dsbcColorsDiscrete\n"))
  }
  if (n < 1) {
    warning("returning all color in this palette\n")
    n <- maxcolors[[name]]
  }
  if (n > maxcolors[which(name == namelist)]) {
    warning(paste("n too large, allowed maximum for palette",
                  name, "is", maxcolors[which(name == namelist)]),
            "\nReturning the palette you asked for with that many colors\n")
    n <- maxcolors[[name]]
  }
  
  #################################################################################
  ################################## fetch color ##################################
  #################################################################################
  ## ggsci
  if (name %in% colnames(ggsci)){
    suppressPackageStartupMessages(library("ggsci"))
    if (name == "npg"){
      colors<- eval(parse(text=paste("pal_",name,"('nrc')(",n,")",sep="")))
    }else if (name == "lancet"){
      colors<- eval(parse(text=paste("pal_",name,"('lanonc')(",n,")",sep="")))
    }else if (name == "d3"){
      colors<- eval(parse(text=paste("pal_",name,"('category20')(",n,")",sep="")))
    }else if (name == "startrek"){
      colors<- eval(parse(text=paste("pal_",name,"('uniform')(",n,")",sep="")))
    }else if (name == "tron"){
      colors<- eval(parse(text=paste("pal_",name,"('legacy')(",n,")",sep="")))
    }else if (name == "futurama"){
      colors<- eval(parse(text=paste("pal_",name,"('planetexpress')(",n,")",sep="")))
    }else if (name == "rickandmorty"){
      colors<- eval(parse(text=paste("pal_",name,"('schwifty')(",n,")",sep="")))
    }else if (name == "simpsons"){
      colors<- eval(parse(text=paste("pal_",name,"('springfield')(",n,")",sep="")))
    }else{
      ## bug?
    }
  }
  
  ## RColorBrewer
  if (name %in% colnames(RColorBrewer)){
    suppressPackageStartupMessages(library("RColorBrewer"))
    colors<- eval(parse(text=paste0("brewer.pal(",n,",\"",name,"\")")))
  }
  
  ## grafify
  # https://grafify-vignettes.netlify.app/colour_palettes.html
  if (name %in% colnames(grafify)){
    suppressPackageStartupMessages(library("grafify"))
    #colors<- eval(parse(text=paste("grafify:::graf_palettes$",name,"[1:",n,"]",sep="")))
    colors<- eval(parse(text=paste("colorRampPalette(grafify:::graf_palettes$", name, ")(", n, ")")))
  }
  
  ## custom
  if (name %in% colnames(custom)){
    customPalettes <- list(
      default = c("#E69F00","#56B4E9","#009E73","#F0E442","#0072B2","#D55E00","#CC79A7",#fromokabe_ito
                  "#F3C300","#875692","#F38400","#A1CAF1","#BE0032","#C2B280","#F99379",#from grafify:::graf_palettes$kelly
                  "#604E97","#B3446C","#882D17","#8DB600","#654522","#2B3D26",#from grafify:::graf_palettes$kelly
                  "#999999" #grey
      ),
      dis_111 = c("#00C2A0","#FF9896","#604E97","#F6A600","#1F77B4","#FF8247","#FF90C9",
                  "#4DAF4A","#17BECF","#E64B35","#8B008B","#FFF68F","#3C5488","#FFBB78",
                  "#5A0007","#76EE00","#004D43","#7B4F4B","#A020F0","#C2B280","#DDEFFE",
                  "#FF7F24","#FF2F80","#4FC601","#0AA6D8","#F99379","#EE30A7","#B5BD61",
                  "#000080","#F38400","#D62728","#63FFAC","#00A087","#FF4A46","#6A3D9A",
                  "#8B6508","#377EB8","#B15928","#E7298A","#B2DF8A","#1CE6FF","#8C564B",
                  "#B903AA","#FFFF33","#8FB0FF","#FF7F00","#E41A1C","#00FF00","#008B8B",
                  "#FF7256","#FF34FF","#FFFF00","#1E90FF","#FF7F0E","#997D87","#A1C299",
                  "#006FA6","#FF4500","#FF1493","#8DB600","#191970","#FFA500","#FF6A6A",
                  "#279E68","#809693","#BA0900","#AA40FC","#E6AB02","#63B8FF","#A65628",
                  "#FF6EB4","#1B4400","#4DBBD5","#882D17","#E377C2","#848482","#3B5DFF",
                  "#654522","#E31A1C","#54FF9F","#00FFFF","#FFE4E1","#984EA3","#FFD700",
                  "#A1CAF1","#D95F02","#B3446C","#2B3D26","#00BFFF","#FFAA92","#A30059",
                  "#6B7900","#0000A6","#B79762","#FF3030","#008941","#0067A5","#FF6347",
                  "#FF00FF","#DCD300","#6495ED","#FFA54F","#E68FAC","#33A02C","#7570B3",
                  "#E25822","#F781BF","#66A61E","#666666","#A6761D","#1B9E77"
      ),
      dis_333 = c("#00C2A0","#FF9896","#604E97","#F6A600","#1F77B4","#FF8247","#FF90C9",
                  "#4DAF4A","#17BECF","#E64B35","#8B008B","#FFF68F","#3C5488","#FFBB78",
                  "#5A0007","#76EE00","#004D43","#7B4F4B","#A020F0","#C2B280","#DDEFFE",
                  "#FF7F24","#FF2F80","#4FC601","#0AA6D8","#F99379","#EE30A7","#B5BD61",
                  "#000080","#F38400","#D62728","#63FFAC","#00A087","#FF4A46","#6A3D9A",
                  "#8B6508","#377EB8","#B15928","#E7298A","#B2DF8A","#1CE6FF","#8C564B",
                  "#B903AA","#FFFF33","#8FB0FF","#FF7F00","#E41A1C","#00FF00","#008B8B",
                  "#FF7256","#FF34FF","#FFFF00","#1E90FF","#FF7F0E","#997D87","#A1C299",
                  "#006FA6","#FF4500","#FF1493","#8DB600","#191970","#FFA500","#FF6A6A",
                  "#279E68","#809693","#BA0900","#AA40FC","#E6AB02","#63B8FF","#A65628",
                  "#FF6EB4","#1B4400","#4DBBD5","#882D17","#E377C2","#848482","#3B5DFF",
                  "#654522","#E31A1C","#54FF9F","#00FFFF","#FFE4E1","#984EA3","#FFD700",
                  "#A1CAF1","#D95F02","#B3446C","#2B3D26","#00BFFF","#FFAA92","#A30059",
                  "#6B7900","#0000A6","#B79762","#FF3030","#008941","#0067A5","#FF6347",
                  "#FF00FF","#DCD300","#6495ED","#FFA54F","#E68FAC","#33A02C","#7570B3",
                  "#E25822","#F781BF","#66A61E","#666666","#A6761D","#1B9E77",
                  "#00C2A0","#FF9896","#604E97","#F6A600","#1F77B4","#FF8247","#FF90C9",
                  "#4DAF4A","#17BECF","#E64B35","#8B008B","#FFF68F","#3C5488","#FFBB78",
                  "#5A0007","#76EE00","#004D43","#7B4F4B","#A020F0","#C2B280","#DDEFFE",
                  "#FF7F24","#FF2F80","#4FC601","#0AA6D8","#F99379","#EE30A7","#B5BD61",
                  "#000080","#F38400","#D62728","#63FFAC","#00A087","#FF4A46","#6A3D9A",
                  "#8B6508","#377EB8","#B15928","#E7298A","#B2DF8A","#1CE6FF","#8C564B",
                  "#B903AA","#FFFF33","#8FB0FF","#FF7F00","#E41A1C","#00FF00","#008B8B",
                  "#FF7256","#FF34FF","#FFFF00","#1E90FF","#FF7F0E","#997D87","#A1C299",
                  "#006FA6","#FF4500","#FF1493","#8DB600","#191970","#FFA500","#FF6A6A",
                  "#279E68","#809693","#BA0900","#AA40FC","#E6AB02","#63B8FF","#A65628",
                  "#FF6EB4","#1B4400","#4DBBD5","#882D17","#E377C2","#848482","#3B5DFF",
                  "#654522","#E31A1C","#54FF9F","#00FFFF","#FFE4E1","#984EA3","#FFD700",
                  "#A1CAF1","#D95F02","#B3446C","#2B3D26","#00BFFF","#FFAA92","#A30059",
                  "#6B7900","#0000A6","#B79762","#FF3030","#008941","#0067A5","#FF6347",
                  "#FF00FF","#DCD300","#6495ED","#FFA54F","#E68FAC","#33A02C","#7570B3",
                  "#E25822","#F781BF","#66A61E","#666666","#A6761D","#1B9E77",
                  "#00C2A0","#FF9896","#604E97","#F6A600","#1F77B4","#FF8247","#FF90C9",
                  "#4DAF4A","#17BECF","#E64B35","#8B008B","#FFF68F","#3C5488","#FFBB78",
                  "#5A0007","#76EE00","#004D43","#7B4F4B","#A020F0","#C2B280","#DDEFFE",
                  "#FF7F24","#FF2F80","#4FC601","#0AA6D8","#F99379","#EE30A7","#B5BD61",
                  "#000080","#F38400","#D62728","#63FFAC","#00A087","#FF4A46","#6A3D9A",
                  "#8B6508","#377EB8","#B15928","#E7298A","#B2DF8A","#1CE6FF","#8C564B",
                  "#B903AA","#FFFF33","#8FB0FF","#FF7F00","#E41A1C","#00FF00","#008B8B",
                  "#FF7256","#FF34FF","#FFFF00","#1E90FF","#FF7F0E","#997D87","#A1C299",
                  "#006FA6","#FF4500","#FF1493","#8DB600","#191970","#FFA500","#FF6A6A",
                  "#279E68","#809693","#BA0900","#AA40FC","#E6AB02","#63B8FF","#A65628",
                  "#FF6EB4","#1B4400","#4DBBD5","#882D17","#E377C2","#848482","#3B5DFF",
                  "#654522","#E31A1C","#54FF9F","#00FFFF","#FFE4E1","#984EA3","#FFD700",
                  "#A1CAF1","#D95F02","#B3446C","#2B3D26","#00BFFF","#FFAA92","#A30059",
                  "#6B7900","#0000A6","#B79762","#FF3030","#008941","#0067A5","#FF6347",
                  "#FF00FF","#DCD300","#6495ED","#FFA54F","#E68FAC","#33A02C","#7570B3",
                  "#E25822","#F781BF","#66A61E","#666666","#A6761D","#1B9E77"),
      oat = c("#FCCE3B","#78B9DE","#9FC919"),
      macaca = c("#62B197","#DF811C","#57ABDC","#8F4C9A","#E58560","#3778AD","#E0AB17","#2DAFB6","#DBDBDB"),
      TBP = c("#62B197","#DF811C","#57ABDC","#8F4C9A","#6C9A8F","#8DB600","#E58560","#3778AD","#E0AB17","#2DAFB6","#DBDBDB"),
      cm104pair=c("#C16190","#DBAAC1","#069292","#93BDBE","#2C8241","#93B18A","#C49333","#DDC18D","#304F9A","#8B91C2","#60348C","#9D87BA","#C56432","#DCA583","#929497","#C6C8C9"),
      cm104dark=c("#C16190","#069292","#2C8241","#C49333","#304F9A","#60348C","#C56432","#929497"),
      cm104light=c("#DBAAC1","#93BDBE","#93B18A","#DDC18D","#8B91C2","#9D87BA","#DCA583","#C6C8C9")
    )
    colors <- customPalettes[[name]][1:n]
  }
  
  if (plot){
    library(scales)
    pdf("dsbcColorsDiscrete.pdf",height=4,width=4)
    txt <- vector()
    for(x in namelist){
      show_col(dsbcColorsDiscrete(name=x),cex=0.5);title(x)
      txt <- c(txt,paste(c(x,dsbcColorsDiscrete(name=x)),collapse="\t"))
    }
    write(txt, file = "dsbcColorsDiscrete.txt",append=F)
    dev.off()
  }else{
    return(colors)
  }
}
